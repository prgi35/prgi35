import  React  from 'react'
import {  Grid, Paper, Avatar, TextField, Button, Typography}from '@material-ui/core'
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
// import Forget from './Components/Forget';
import {Link } from 'react-router-dom'
import FingerprintIcon from '@material-ui/icons/Fingerprint';
import FaceIcon from '@material-ui/icons/Face';
 //import axios from 'axios'



// useEffect =() =>{
//     axios.post(`localhost:3005/user`,{
//         email: email.value,
//         password: password.value

//     })
//     .then()

    
// }
    function buttonWasClicked(){
     alert("Successfuly")
       }


const Login=()=>{


    
        // design for paper style
    const paperStyle={padding:20,height:'70vh',width:280,margin:"20px auto"}
    const avatarStyle={backgroundColor:'#78cce2'} 
    const btnstyle={margin:'8px 0'}
    const forget={textalign:"center"}
      
    return (

    //    desinging a sing in grid paper
       <Grid>
       
           <Paper elevation={10} style={paperStyle}>
               <Grid align="center">
               <Avatar style={avatarStyle}><LockOutlinedIcon/></Avatar>
                        <h2>Sign In</h2>
                        {/* icon of face */}
               </Grid>
                    <Grid>
               <FaceIcon />
                   </Grid>

                   <Grid>
              <TextField label='Username' placeholder='Enter Username' text-align="center" fullWidth /> < br />  <br />  
                  </Grid>

              <Grid>
              <FingerprintIcon />
              </Grid>
              
              <Grid>
              <TextField 
                    label='Password'
                    placeholder='Enter Password'
                    type='password' fullWidth
                 />
                  
                 </Grid>
              <FormControlLabel
              control={
                    <Checkbox
                    name="checkedB"
                    color="primary"
          />
          
        }
 label="Remember me"
      /> <br/>
              {/* { this.state.persons.map(person => <li>{person.name}</li>)} */}

      <Button type='submit' color='primary' variant="contained" style={btnstyle} fullWidth  onClick= {buttonWasClicked} >Sign IN</Button>
       {/* onPress={handleLogin}>Login</Button> */}
      <Typography style={forget}>
          <Link to ="/forget" >
                    {/* for forgot password */}
            Forgot Password?
            </Link>

      </Typography>
      
  <Typography>Do you have an account &nbsp;
           <Link to ="/signup" >
       Sign Up?
  </Link>
 
  </Typography>
      
            </Paper>
       </Grid>
    )
    

    }

// const useFormInput =initialValue =>{
//     const [value, setValue]= useState(initialValue);
    
    
//     const  handleChange = e =>{
//         setValue(e.target.value);
//     }
//     return {
//         value,
//         onChange: handleChange

//     }
//   }
export default Login;



