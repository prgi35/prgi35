
import React from 'react';
// import images from '../../../assets/images';

let slideIndex = 1;
const showSlides = (slideIndex) => {
  return slideIndex;
};

function plusSlides(n) {
  showSlides((slideIndex += n));
  // return showSlides
}

function currentSlide(n) {
  showsSlides((slideIndex = n));
}

// const  slideIndex = 1;
// const showSlides = (slideIndex)
function showsSlides(n) {
  let i;
  const slides = document.getElementsByClassName('mySlides');
  const dots = document.getElementsByClassName('demo');
  const captionText = document.getElementById('caption');
  if (n > slides.length) {
    slideIndex = 1;
  }
  if (n < 1) {
    slideIndex = slides.length;
  }
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = 'none';
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(' active', '');
  }
  slides[slideIndex - 1].style.display = 'block';
  dots[slideIndex - 1].className += ' active';
  captionText.innerHTML = dots[slideIndex - 1].alt;
}

const Slider = () => {
  return (
    <div>
      {' '}
      <h1>Slider</h1>
      <div className="container">
        <div className="mySlides">
          <div className="numbertext">1 / 6</div>
          <img src={"https://www.google.com/search?q=bandar+image&sxsrf=ALeKk01lYuir3mJKnqUEV191fhZDmB_uGw:1620738637000&tbm=isch&source=iu&ictx=1&fir=_lxkt8UNJ655SM%252C9saMJYIIpclcIM%252C_&vet=1&usg=AI4_-kQ_ppVM7niKfodNI8RrzIWX8mliEw&sa=X&ved=2ahUKEwis9-z12cHwAhUM63MBHflrAW0Q9QF6BAgLEAE#imgrc=_lxkt8UNJ655SM"} width="100%"/>
        </div>

        <div className="mySlides">
          <div className="numbertext">2 / 6</div>
          <img src={"https://www.google.com/search?q=bandar+image&sxsrf=ALeKk01lYuir3mJKnqUEV191fhZDmB_uGw:1620738637000&tbm=isch&source=iu&ictx=1&fir=_lxkt8UNJ655SM%252C9saMJYIIpclcIM%252C_&vet=1&usg=AI4_-kQ_ppVM7niKfodNI8RrzIWX8mliEw&sa=X&ved=2ahUKEwis9-z12cHwAhUM63MBHflrAW0Q9QF6BAgLEAE#imgrc=_lxkt8UNJ655SM"} width="100%" height="100px"/>
        </div>

        <div className="mySlides">
          <div className="numbertext">3 / 6</div>
          <img src={"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUSFRgVFRUVGBgYGBgYFRoZGBUYGBgSGhgZGhgZGBgcIS4lHB4rIRgYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHhISHjQkISE0MTExMTE0NDQ0NDE0NDQxNDQ0NDQ0NDQ0NDQ0NDQ/NDQ0ND80NDQ0ND80NDQ/MT8xMf/AABEIAMIBAwMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQADAQIGB//EAD0QAAEEAQIDBQUGAwgDAQAAAAEAAgMRBCExBRJBBlFhcdETIoGRkhQWU1ShwRWx8DIzQkRiguHxQ3KiI//EABkBAAMBAQEAAAAAAAAAAAAAAAABAgQDBf/EACERAAMBAAIDAQEBAQEAAAAAAAABAhEDIRIxQVEEMiIT/9oADAMBAAIRAxEAPwDoj2MwPysXyd6qDsZgflYvk71T9ZC1+E/hn8mc/wDczA/KxfJ3qp9y8D8rF8neqfqI8V+B5MQfcvh/5WP/AOvVT7l4H5WP5H1T9ZR4r8DyZz/3M4f+Vi+TvVT7mYH5WL5O9U/pQo8V+B5M5x3Y3A/Kx/J3qqvujgDfGi+R9V0Ur0DO4n1XLkuJXZczVCOXstgjbGi+R9VQey2ERf2eIfA+qdsjIOhtXDG6n4hYa5ap/wDPSNUxi7OW+7OJ+Xj+np81lvZPGJ/uI/DRdczGvRoJ7kTHw69XaeCSVfpeSclD2JxHbxM+lEHsHiV/cs+ldizDa3ZXctJ7X6LEzzjK7FwMGkEZ/wBqSZXAoGf+Bgr/AE9V666MFK8/hzHa8oUuq/Q8UeaQ8EgND2Md/wDr1qysM4dii7giJ5iBp3LqcnhxaTyDX1SLM4a9mpaU/OkHijfF4XhUC7HjJ7g0pxh9nMCT/KxAeR1/Vc8xxHgm/DM8tPKSu3FzJvKOVx10OPuhgbDFi+Tq/mtm9jcDc4sfyd6pjh5TXAdK/VGtdf7LalLWoyt0hF9zcD8rF8neq1PY7A/KxfJ3quhKqeU/FfgvNnOO7JYP5aL5H1Q8nZTCH+Xj+R9V0rwhJwn4r8GqZzE3ZrEG2PH8kun4HjDaCP6V085SvJChyippnL5HC4RtFH9IQw4fF+Ez6QnGU1B0s9GiV0Dfw6L8KP6QoilFGlYj2NYUUW8wmaUpYUtAEWVhVueAk2Bs5yollVE2VZoFVFxWTm586k0cfFvbN3O6lUyS9yoncT1pa4xs+AWLXT1mmV8DYDSLjcz/ABFLZ3OGyQ8RfK8H2Tw1wvRwNfNUnh18dO0/iLG9ysZxFp6heSDByy65Xvr/AEbKninFPZTE40rwG1bHm9aHNr5rotzSGknjPaWzg9VtIV512c7WiYAOIa8bhdtDk87bBtLdBzgYx/eq8nbdDtfaD4tl+zZd6nRc66HK0mKAdDvaJfitOlApPw/K5/eTNuVW2pTzoK9ibivB2HYa/ukE+MYzVfFdlK7nNlLOJYvO2gk5eEsS8O4l7M+9ZHUrrsLKDxYK4ObHc3avFOuASAmr1/Raf5uV74sz80dajr20o5YjboNFly3mQokQkxRUiGlCBi2YbpZkBNpwluQ1Sy5E2SxAvYmmQxAyhZbRqj0D0otlFzLPX1FhC5GWGLXfIpWsxRFW8RfI+lUJL1tczxriL3N9ywheBcRl5uV4PyWKv6a3o2z/ACpLWdTPmeOyTzZD3u0NBX5LQ7VTGhA1pcK56rpguOZLoI+ULMppbPeepoeCFe+70J7lx8i0gTIl6CvNb4unx6hUmPmP7dyLjbRrZdpXQ17DImXupk8NY7WtVmN/QC1YS4+SEyxLPw57Dob+KV5uGJNHw8x2sDX5rrRQ6jT5rQ6+Sehp56zsq9sgfCXM11a4afNdzw8vjbRrbXXS/BbyP1obpW/jMQk9kXgPOgHee4IVdi7aweMyK/ZKOKvMhq6ACt9tRrqqMnUFJ9gngTwXCtgANjqU9ZiNboFzEPG2YrAwkNG+vVWRdtMY/wCPbc0aHmuqaJqX7OldhhCZWHpoVXh8bilFse1w8CiBOHaJ9Mhpo5bLxy0m6KWNc6N9tsarqeK44Iutlz7q63v8Fz/zaaClsnV8NyOdgsFH0Eo4JIC0DVOA1erL1Hn0sZU9qEkCNchJAqJAJgl+Q1MZwgJwpZaFU7UunTScJbMNVl5DVAPyqLdRcTqequdoUD7Dm36oqV2lId0o2Vc9KqI4J8UUPwm1RCBczk05QmUk1CyQgMjKad1lvEjR2Ya699kSCK3+CGa8GlrPIAO5Z/IWG8kgQ0svS7J/qkFJlE6DT9/FXYsTtyNOiuZ1ib6CmUBfzW7H2sCMk9a8la9gGpA8+trVK6I0uZIB4KPmd128PRDMjLjeoHdui2xV+6hlyysOadRfMFqJidKr1Vj2g7ClkMAPkk0UAZ0hYxzmizyleTcPZLNmsa679oC7fRoNleuZL962630QUOFHHzThjQ4tou8PBOX4g02ZzuIMgDpnkcuteS5aPto2V5DWEN6bajyS7tHBk5bg2JjjGNtdEXwLsa+NpkmoOr3Wg3XmVWLx1i1+WfBzPisy2crxY303HktH4T8eB7MdjHh4AeCAHco1WvCsh8ZotFA7+qd5sBdb2aE6kbWPBCpyJpV0eaZD34rg9gdGb1brS73sv2iE7W2fe6+aS8U1BbIwnwI6JRhYxheHwuFXq1x1R5fRuGuj1rKfzUO9cxmN5HVrqpw7iz5OUOOqp4lNbxSG9JqWkdDwN4LdHA/zCeNJpcp2fcA+ro9F1bR3r0eJ7KPP5FlGHFDSol4Qsi6nMCmS+dMJkvnU0dELZ0sl3TSdLZBqsnIaoKaUW/KouWnbD0aZ5JKGeRWuiucw9EHxEe73Li3vZcykLH5fvVut5pwRoPNC8Mc0vJdrX80zzg00Ghcb/wAgyuDbm8EPNPzGhRRDm6UO5CvY1nn1WbRmYYA/u3THGZRru3QWFI0OrxRr3np81p4iKDXzNA0o+CCezmNkfrsoyMk96KZBW+i1EFTAzazfxRULABudVVFE29Ab/QK8yMYDZ2U+JS79GzGB1nu6oXKyGRk2UlzePsLwxpILjQqt7RWTwdsjac911uD18k/HfRcz32asymT2G69DazNF7Ucg0aND5Lm86J+G8EONHSyNPiU54fxChThXW+hUY/pbX4Fy4wiAa0UAKCrlfQAOgpGvJeAR80A6EAlzvePQHYDySaI0XtgaX2Op10PzTIS1XeNNv8KHMnI/XToKWk04DtTRtDQl7GT42PbqA6+8JHk8Eh5rLaPWj0R7Mks3rw8kJkT9bSK0qGKG0GaBVZjQHjqhH5lWL1/dWxv5tT4Kn0iKejPAkDXhdnEbAo9FwcTS02ux4ZLbQtv8tasMXPP0LchpAiJENKtZnApkvnTCZL51NejpPsXzpdJumMwQEgWPlNcFSi2pRcTseiubqg8+iKKYOclmRO3mJNaLki/pVjYLWAuH6rQjXVSbiAA3A7lU2Vp66nWvBcuV9Ca7KMmfl80tEpNlZ4nMeahVdVjCZzBcMGMeHxFx22/VNBER8VRiDlpGg2Vr4pxHKn2bsIbWioneeYCzRNf9q72vgsscOq7CMOlbGKvVczxyeSQERMc4kgCtte8rpJA0OJAu9r1WzpG1egAGwACG0dE8PMMXs1mDIjfJy8oe0u5XXTfJenvqhWpN6Je+ZhBPdqO+gk2N2jZzWHgOHQlJUjrM79OmlYzl99rT5gH+aVZr2P0AAds3YLnuO9qwPda7nedq2HmuSfxiYe+4n9kN76G0l7PROHZLpG0CdCQe6waIRc8J3c7lHcuc7HZnMzmvc6jxTbiuS09TXd1U0ujl7ZVNIBoNQTugeJP90PBujRQrZLAAdp08+9K+IZbuQ2dyB8tkpWk0xmeIUB1QORxIlJBM7vKugIO6vMIdMvbISfFOOGg6fFK2R2RXX9E4wGVS50xpDEOsX0tdbwb+x4dFx5k5fJdXwN9sC1fyPsz866GrkLKiXIWRbzKBzoCVHTlAzKKLkXzIB41R8qBkGqx8psg05FFsouR0Oh4v2jijafeBPmvP+J9rXPsNdS4573Hcn5qohNca+sb5c9I6bE444Evc4k7NFrrOAZTpHl7j0peYiMgj/td72Px5XgkNIbRskdFz5eNZ0SqbfY6yXBz6Hx80wwGUUux4qedeqd4kdUs0xrLpl7HUfii2Sa6IRw1WRItc9EIJe+7Qkk1eP7BZfMAEuzMrlBJ+A71NMaChlW7fyHgt5XE3e1X81z/2ss99xo7n0VT+LF4B17+uoSLQwyZyxpbzDUaX3dVyvE+EbvFe8dKPXdNsjIYRzkiwNB1BQGVml3I1pA3Nnpp3oHuCbGxhdVrsn0fB2FvI81zDu/s9yowIWNNk2TZvuRTczmJKFWA+w7gfCH4rCx2tE07oQdRS0z3uF822tabhMMfML2Bu9BKOKPcCAeq6N6ifQqnNOtpIB/RCZzbbXiEdlsoCxSCebGqU9HOir7KQB4q+CKtUyhkD2gV0Q72a6KKr4CkIxGCjfmEazQjyS6KQbeKOZICb8lze6V8LJX3S7Ps8z/8AMLgMiXWl2fZfKBZW/etf8jyuzhzrV0dG8oV6JJQ0i9ExoCnS+VMJ0BMudHSQCZAyI2ZBuWLk9muDCi2UUHQ5F/CGtb3oaDhHO4Na2yf63T+OOR+5pou9tU97P4wfKGtqgLJ71Cph4/SdnOyDGUXjmO9dAuzyMVkcZawAaIuCAMGiA4tke7SH0uw05zGio699pgza1UyOhfetC/SlKWEvst5/+Vh7wFQZBSofOq0akxPkVrfkl82UP7Tj5eAWuXMBukWfPen6fupbOiRXxTPL9tGhK2cQeASCT0/rwUlJeR3LZ8HuppoVFTssgXzeQ7yse3J92ySDr5dVUY617rKqifXM4/LvtXiYhtHlODQ3pRP9FWQPIa0ed/sljJg5oB8b8G7o7HfoB3i/LuUNDTHODkEaWmz2h9OckeEO/puimzF25OnRA32b5Ja89aGgSqWE9E0cL2WroQAh1iObRVBTGE1qqZLIFdVrLL0/qldhglj7G23/AAuRa9A0ZoWi+f3QUA73RustnHLSskMe8ON+CP7O8UDJQ2/BJxLqCPiqYWETBze8Ko1VoKVSZ7PGbCpkWuBKHRsI7hfnS2lXrS9WnnUseAc6XzJhOl8ymi4AZkE/dGTIQrFfs1yRRZUXMsEDOR5Yda1PkmXB5fYS30sfFvgq86ENm5r0c2j5nZX4cftGAnVzNP8AaFz0tf8ASO3bOHs5geiQ5s3O7yVDJXR3R07kO6TQuRukUsNpJgNPBCOyRaFycnUoVsyGxzIa+c3shZ5dbVcshQs0iWl4UZk17lLH+9uisl6CLtUDwjY1l40VjHKqRyaJYPId/JBSsrYf9ot7CdlbHD0VLUQ2D4+NYA+JRrI/etWNZyrLGm0mNF7Ha0r2HcKhjFsHG0DwtjeRorJH01VwjW1pLJpXUqGwQukk97XonGBPbD0vQeSQ5Bt1D4pphdENBoNmmjSoDCGovKZbvisTEBpF9FcojTXHbaNhi1BQmE7ROMVlqsKR13Z3I93kPmnL0k7PY5BLzdbBOnr0OFvxWmHmS8ugOZL5kfOEDMqoJAJQhXBFzIaliv2apNaUVnKouZ0M8ZeLHL0IJKrxcksYdhZJSTi/Egz3bQR4pzVquTllx0jp2ZfMd1bNkU1JcA9Sd1nJyeiS6FXbMvnN34qCQ+A7u9AunvqtHTeJQCC3OpDPk7lWZrWBqLTQ0zR40JKDe7VEyOpU8llNDb6Nm6q5mKSURiY9lMmxUrlHGmLmYivjxQLRj2gbIdz02wSApmarLW0t5CtebRQykZpZYsMeKWzDZS0rTa62QsoFX8kS7lb40Pgl8896DRT9FoLu7+tUyxNAD4pbEDzI72nLXh/NPCWyyV4u0PlRc5sIXIyKIPemHDjzAWrSFhbhxhrdU44VH7R4aOpHyS8tFrpOy+LzP5hs0WrifKkhW8nTrIYeRoaNgtXlEKh69KViMDesEmS+dHzJfOoo6QBTIbqiZlRSx37Ncm9KKWouZZ5fl5RkeXHv08lbCS5wAS4SIvh7zzX3bqqnoU38OmhyKu+mgQWTm638ELNlBos9UrM5Js9VzUaHkNftFlERy95SVjyjWPoa6eaHOD8hox4O5Wkz0ubli9CFsMi0nI1SL2uvdXRNs7oP2iJxpAPNJA6HuJQPwRRdolMM6K+1aUVekYbuf4oOV5WZnAbIZzvFS2My8nzWvtFo59dVX7VA0ECRbh9IMvWXTUpwehE2VQpAPfVkhaOlG5OqFnnva05lkth2KdCVcH2QEHw9xdY710WNwdzwHAb7q5htkVaOd4phPjddHlOx6d6O4K+wu74Vw72rDFKwEba7jxCR53Zp+E+weaN2x7vArtfE5WinlT6KWR3uu87L4vJFzV/aP6Lk8LFdI9rAN/5L0XHhEbWtHQAK/wCeO9OfPfWGHBCyoqRCylbTKBTICVMJUBKuNnaAKVUAK+VUtKx17NUmVFvSypLw8XREE3L8dCruKYhike0igHGvLoq8OIlw0tdm+jMvZY1jpDVkgbeSpBAJG6cNYGNL/D90icdT8VK7KbwKDxWqommLlUSsJqUhN6WRogOPQoYNPiioGnYopDllsMtq1s9FAPcWkgKsylT4aPyH+PljvRTMvu1XMtyCFcJebUGj+hUPjZSpHQnJ8lVI/wAUjblPC1dmOS/8mPyQ3e/xWpmSj7W5VvnJ6priYnaGr8oDqh5cvxS+/Fa2rXGkQ7bCZpr2JVcc7m7FVLIV4kTp03BOJN5hzsB229F6zwSOORgc39l4jw5tEbr0bsvM0EU5zSfkunE8eEWtR6HFitabACsyMRkjSx4BBWmM51C6PiEYAtDOHaFeBwaOAlzLvpfTyRjkQQqXg9yJSXoG2/YO9CyoqQIWQJtggOVASo+ZAzBcbO0AMqqarZVWwLHXs1SWKLCykdNPGpJCdyT5klYY495UUXcyELz3n5rUqKIAigUUQBkre1FEAaFYUUQBFFFEAZWFFEARRRRAEUUUQBFAoogDZrj3lbsyHjZ7h8SoogC5vEpvxpfrf6rb+Jz/AI0v1v8AVYUQBn+Jz/jS/W/1Wv8AEp/xpfrf6qKIAx/Epvxpfrf6rH8Rm/Fl+t3qoomBj7fL+LJ9bvVT7bL+JJ9TvVRRIDH2yT8R/wBTvVY+2SfiP+p3qsqIAn2yT8R/1O9VFFEAf//Z"} width="100%" height="100px"/>
        </div>

        <div className="mySlides">
          <div className="numbertext">4 / 6</div>
          <img src={"https://i.ytimg.com/vi/ZT3hs9v2Uto/hqdefault.jpg"} width="100%"height="100px"/>
        </div>

        <div className="mySlides">
          <div className="numbertext">5 / 6</div>
          <img src={"https://i.ytimg.com/vi/ZT3hs9v2Uto/hqdefault.jpg"} width="100%"height="100px"/>
        </div>

        <div className="mySlides">
          <div className="numbertext">6 / 6</div>
          <img src={"https://i.ytimg.com/vi/ZT3hs9v2Uto/hqdefault.jpg"} width="100%"height="100px"/>
        </div>

        <a className="prev" onclick="plusSlides(-1)">
          ❮
        </a>
        <a className="next" onclick="plusSlides(1)">
          ❯
        </a>
{/* 
        <div className="caption-container">
          <p id="caption"></p>
        </div> */}
      </div>
    </div>
  );
};

export default Slider;