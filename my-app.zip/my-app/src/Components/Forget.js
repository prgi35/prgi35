// import React, { Component } from 'react'
// import {  Grid, Paper}from '@material-ui/core'

    

// export class Forget extends Component {
//   paperStyle={padding:20,height:'70vh',width:280,margin:"20px auto"}
//   render() {
//     return (
//       <Grid>
       
//       <Paper elevation={10} style={paperStyle}>
//           <Grid align="center">
//       <div>
//         <div className="sc-password">
//         <h1>Reset Password</h1>
//         <div className="sc-container">
//           <input type="text" placeholder="Username or Email" name="email"/> <br /> <br />
//           <input type="text" placeholder="Get New Password" value="newpwd"/> <br /> <br />
      

//           <button type="submit">Submit</button>
//         </div>
//       </div>
 
//       </div>
//       </Grid>
//       </Paper>
//       </Grid>

//     )
//   }
// }

// export default Forget;
import React, { Component } from 'react';
import { Grid, Paper, Avatar, TextField, Button, Typography}from '@material-ui/core'
import LockOpenIcon from '@material-ui/icons/LockOpen';
import { Link } from "react-router-dom";
const Forget=()=>{
    const paperStyle={padding:20,height:'50vh',width:280,margin:"20px auto"}
    const avatarStyle={backgroundColor:'#78cce2'} 
    const btnstyle={margin:'8px 0'}
    const forget={textalign:"center"}

    return (
        <Grid>
       
           <Paper elevation={8} style={paperStyle}>
               <Grid align="center">
               <Avatar style={avatarStyle}><LockOpenIcon/></Avatar>
                        <h2>Reset Password</h2>

                   

                    
              <TextField label='Email' placeholder='Enter Email' text-align="center" fullWidth /> < br />  <br />  
              <TextField 
                    label='Password'
                    placeholder='Enter Password'
                    type='password' fullWidth
                 />
                    
               </Grid><br />

       

       <Button type='submit' color='primary' variant="contained" style={btnstyle} fullWidth>Submit</Button>

        <Typography>
          <Link to= "/">
            Sign In
          </Link>
          
        </Typography>
       </Paper>
       </Grid>
    )
} 
  
export default Forget;