import React from 'react';
import{ Grid,Paper,Avatar,Typography,TextField,Button,FormLabel } from '@material-ui/core'


import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';

    const paperstyle={padding:'30px 20px', width:300,margin:"2px auto"}
    const headerstyle={margin:0}
    const Avatarstyle={backgroundColor:'#78cce2'}
    const margintop={margintop:8}
    
    function buttonWasClicked(){
        alert("Successfuly")

    }
    
    
    const Signup=()=>{

    return(
        //design a page
        <Grid>
            <Paper elevation={12} style={paperstyle}>
                <Grid align="center">
                    <Avatar style={Avatarstyle}>
                        
                       <AccountCircleIcon/>

                    </Avatar>

               
                <h2 style={headerstyle}>Sign Up</h2> 
                <Typography variant='caption' > Please fill this form is create an 
                
                <hr/>

                </Typography>
                </Grid><br/>
                <form>
      
                <TextField fullWidth label='First Name' placeholder="Enter first name" type='text'/> 
                  <TextField fullWidth label='Last Name'placeholder="Enter Last name" type="text"/>
                  <TextField fullWidth label='E-Mail'placeholder="Enter Email" type="mail" required/>
                  <TextField fullWidth label='Password'placeholder="Enter Password" type="password"/>
                  <TextField fullWidth label='Confirm Password'placeholder="Enter Cofirm Password"/>
                  <TextField fullWidth label='Mobile No.'placeholder="Enter Mobile no."/><br/>
              
                  <br/> <FormControl component="fieldset"style={margintop}>
                 <FormLabel component="legend" align="left">Gender</FormLabel>
                 <RadioGroup aria-label="gender" name="gender1" style={{display:'initial'}}>
                 <FormControlLabel value="female" control={<Radio />} label="Female" />
                 <FormControlLabel value="male" control={<Radio />} label="Male" />
                 <FormControlLabel value="other" control={<Radio />} label="Other" />

  </RadioGroup>    
</FormControl>


                
                  
                

      <br/><Button type="submit" variant='contained' color='primary'  fullWidth onClick={buttonWasClicked} >Sign up</Button>
                </form>
                
            </Paper>
        </Grid>
    )
}


 export default Signup;