import React from 'react';

const PageNotFount= ()=>{
    return(
        <>
        <div>error 404 , page not found</div>
        </>
    )
}
export default PageNotFount;