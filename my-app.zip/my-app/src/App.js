
import React, { Component } from 'react'
import './App.css';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Login from './Components/Login';
import slide from './Components/slide';

import Forget from './Components/Forget';
import Signup from './Components/Signup';
import UserForm from './Components/UserForm';
//import FormUserDetails from './Components/FormUserDetails';
import PageNotFount from './Components/PageNotFount';
import Header from './Components/Header/Header';
// import {BrowserRouter as Router,Route,Link } from 'react-router-dom'

class App extends Component {
  render() {
    return (
      <>
        <Router>
          <Switch>
            {/*<Route exact path="/" component={Login} />
            <Route exact path="/forget" component={Forget} />
            <Route exact path="/signup" component={Signup} />
            {/* <Route exact path="/login">*/}
            {/*<Login />*/}
            {/*</Route> */}
            {/*<Route exact path="/" component={Login} />*/}
            <Route path= "/header" component = { Header} />
            <Route exact path="/userform" component={UserForm} />
            {/*<Route path= "/slide" component={slide}  />*/}




            
            <Route path="*" component={PageNotFount} />
            
          </Switch>
        </Router>
      </>
    );
  }
}
export default App;
