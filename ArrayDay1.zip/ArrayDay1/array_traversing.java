package ArrayDay1;

public class array_traversing {

	public static void main(String[] args) {
		// creation of an array
		int[] array = new int[] { 3, 5, 2, 5, 14, 4 };
			//deaclaration of an array
		
		//intialization of an array
		
		 System.out.println("Contents of the array: ");
	      for (int element:array) {
	         System.out.println(element);
	      }

	}

}
