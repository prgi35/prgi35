// WAP to create a dynamic array. Dynamic Array means when user want to input the number 
//more than size of array it will increase the size of array without throwing exception
package ArrayDay1;

public class IncrementDecrementOrder {

	public static void main(String[] args) {
		int[] arr = {2,9,33,7,45,8,5};
		
		int temp = 0;
		for(int i=0; i<= (arr.length/2) ; i++){
			for (int j = i+1; j< arr.length/2; j++){
			            temp = arr[i];    
		                arr[i] = arr[j];    
		                arr[j] = temp;   
		               
		            }   
			 
			}
	
		for(int i= (arr.length/2); i<arr.length; i++){
			for (int j = i+1; j < arr.length; j++){
		   if(arr[i] > arr[j]) {    
		                temp = arr[i];    
		                arr[i] = arr[j];    
		                arr[j] = temp;
		            
		        } 
		
		}
     
		}
		for(int i=0; i<arr.length; i++) {
			System.out.print(" "+arr[i]);
		
		}
	
	}
}
		
