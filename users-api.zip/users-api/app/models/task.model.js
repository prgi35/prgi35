const sql = require("./db.js");

// constructor
const Task = function (task) {
  this.taskCode = task.taskCode;
  this.taskTitle = task.taskTitle;
  this.taskDescription = task.taskDescription;
  this.projectCode = task.projectCode;
  this.employeeCode = task.employeeCode;
  this.estimateTime = task.estimateTime;
  this.actualTime = task.actualTime;
  this.status = task.status;
  this.comment = task.comment;
  this.createdDate = task.createdDate;
};

Task.create = (newTask, result) => {
  sql.query("INSERT INTO task SET ?", newTask, (err, res) => {
    if (err) {
      // console.log("error: ", err);
      result(err, null);
      return;
    }

    // console.log("created task: ", { id: res.insertId, ...newtask });
    result(null, { id: res.insertId, ...newTask });
  });
};

Task.findById = (taskId, result) => {
  sql.query(`SELECT * FROM task WHERE id = ${taskId}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found task: ", res[0]);
      result(null, res[0]);
      return;
    }

    // not found task with the id
    result({ kind: "not_found" }, null);
  });
};

Task.getAll = (result) => {
  sql.query("SELECT * FROM task", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("task: ", res);
    result(null, res);
  });
};

Task.updateById = (id, task, result) => {
  sql.query(
    "UPDATE task SET taskCode = ?, taskTitle = ?, taskDescription = ?, projectCode = ?, employeeCode = ?, estimateTime = ?, actualTime = ?, status = ?, comment = ? WHERE id = ? ",
    [
      task.taskCode,
      task.taskTitle,
      task.taskDescription,
      task.projectCode,
      task.employeeCode,
      task.estimateTime,
      task.actualTime,
      task.status,
      task.comment,
      id,
    ],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // not found Task with the id
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("updated Task: ", { id: id, ...task });
      result(null, { id: id, ...task });
    }
  );
};

Task.remove = (id, result) => {
  sql.query("DELETE FROM task WHERE id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found task with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted task with id: ", id);
    result(null, res);
  });
};

Task.removeAll = (result) => {
  sql.query("DELETE FROM task", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} task`);
    result(null, res);
  });
};

module.exports = Task;
