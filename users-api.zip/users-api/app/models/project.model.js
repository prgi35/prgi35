const sql = require("./db.js");

// constructor
const Project = function (project) {
  this.projectCode = project.projectCode;
  this.projectName = project.projectName;
  this.clientName = project.clientName;
  this.address = project.address;
  this.state = project.state;
  this.country = project.country;
  this.createdDate = project.createdDate;
};

Project.create = (newProject, result) => {
  console.log("newProject:", newProject);
  sql.query("INSERT INTO project SET ?", newProject, (err, res) => {
    if (err) {
      // console.log("error: ", err);
      result(err, null);
      return;
    }

    // console.log("created user: ", { id: res.insertId, ...newProject });
    result(null, { id: res.insertId, ...newProject });
  });
};

Project.findById = (projectId, result) => {
  sql.query(`SELECT * FROM project WHERE id = ${projectId}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found user: ", res[0]);
      result(null, res[0]);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};

Project.getAll = (result) => {
  sql.query("SELECT * FROM project", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("project: ", res);
    result(null, res);
  });
};

Project.updateById = (id, project, result) => {
  sql.query(
    "UPDATE project SET projectCode = ?, projectName = ?, clientName = ?, address = ?, state = ?, country = ? WHERE id = ?",
    [
      project.projectCode,
      project.projectName,
      project.clientName,
      project.address,
      project.state,
      project.country,
      id,
    ],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // not found Project with the id
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("updated Project: ", { id: id, ...project });
      result(null, { id: id, ...project });
    }
  );
};

Project.remove = (id, result) => {
  sql.query("DELETE FROM project WHERE id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted project with id: ", id);
    result(null, res);
  });
};

Project.removeAll = (result) => {
  sql.query("DELETE FROM project", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} project`);
    result(null, res);
  });
};

module.exports = Project;
