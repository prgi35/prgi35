const sql = require("./db.js");

// constructor
const Employee = function (emp) {
  this.empCode = emp.empCode;
  this.userName = emp.userName;
  this.email = emp.email;
  this.password = emp.password;
  this.profileImage = emp.profileImage;
  this.gender = emp.gender;
  this.moblie = emp.mobile;
  this.breakTime = emp.breakTime;
  this.shiftTime = emp.shiftTime;
  this.doc = emp.doc;
  this.createdDate = emp.createdDate;
};

Employee.create = (newEmp, result) => {
  sql.query("INSERT INTO employee SET ?", newEmp, (err, res) => {
    if (err) {
      // console.log("error: ", err);
      result(err, null);
      return;
    }

    // console.log("created user: ", { id: res.insertId, ...newUser });
    result(null, { id: res.insertId, ...newEmp });
  });
};

Employee.findById = (empId, result) => {
  sql.query(`SELECT * FROM employee WHERE id = ${empId}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found user: ", res[0]);
      result(null, res[0]);
      return;
    }

    // not found Employee with the id
    result({ kind: "not_found" }, null);
  });
};

Employee.login = (params, result) => {
  sql.query(
    `SELECT * FROM employee WHERE email = '${params.email}' AND password = '${params.password}'`,
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }

      if (res.length) {
        // console.log("found user: ", res[0]);
        result(null, res[0]);
        return;
      }

      // not found Employee with the id
      result({ kind: "not_found" }, null);
    }
  );
};

Employee.getAll = (result) => {
  sql.query("SELECT * FROM employee", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("users: ", res);
    result(null, res);
  });
};

Employee.updateById = (id, emp, result) => {
  sql.query(
    "UPDATE employee SET empCode = ?, userName = ?, email = ?, password = ?, profileImage = ?, gender = ?, mobile = ?, breakTime = ?, shiftTime = ?, doc = ?  WHERE id = ?",
    [
      emp.empCode,
      emp.userName,
      emp.email,
      emp.password,
      emp.profileImage,
      emp.gender,
      emp.mobile,
      emp.breakTime,
      emp.shiftTime,
      emp.doc,
      id,
    ],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // not found User with the id
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("updated employee: ", { id: id, ...emp });
      result(null, { id: id, ...emp });
    }
  );
};

Employee.remove = (id, result) => {
  sql.query("DELETE FROM employee WHERE id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Customer with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted employee with id: ", id);
    result(null, res);
  });
};

Employee.removeAll = (result) => {
  sql.query("DELETE FROM employee", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} employee`);
    result(null, res);
  });
};

module.exports = Employee;
