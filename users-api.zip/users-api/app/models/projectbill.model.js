const sql = require("./db.js");

// constructor
const ProjectBill = function (bill) {
  this.taskCode = bill.projectCode;
  this.clientName = bill.clientName;
  this.taskDetails = bill.taskDetails;
  this.adarshCostLow = bill.adarshCostLow;
  this.adarshCostHigh = bill.adarshCostHigh;
  this.percentage = bill.percentage;
  this.parathCostLow = bill.parathCostLow;
  this.parathCostHigh = bill.parathCostHigh;
  this.costToClientLow = bill.costToClientLow;
  this.costToClientHigh = bill.costToClientHigh;
  this.createdDate = bill.createdDate;
};

ProjectBill.create = (newProjectBill, result) => {
  console.log("newProjectBill:", newProjectBill);
  sql.query(
    "INSERT INTO projectbilldetails SET ?",
    newProjectBill,
    (err, res) => {
      if (err) {
        // console.log("error: ", err);
        result(err, null);
        return;
      }

      // console.log("created user: ", { id: res.insertId, ...newProjectBill });
      result(null, { id: res.insertId, ...newProjectBill });
    }
  );
};

ProjectBill.findById = (projectbilldetailsId, result) => {
  sql.query(
    `SELECT * FROM projectbilldetails WHERE id = ${projectbilldetailsId}`,
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }

      if (res.length) {
        console.log("found user: ", res[0]);
        result(null, res[0]);
        return;
      }

      // not found ProjectBillDetails with the id
      result({ kind: "not_found" }, null);
    }
  );
};

ProjectBill.getAll = (result) => {
  sql.query("SELECT * FROM projectbilldetails", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("project: ", res);
    result(null, res);
  });
};

ProjectBill.updateById = (id, bill, result) => {
  sql.query(
    "UPDATE projectbilldetails SET taskCode = ?, clientName = ?, taskDetails = ?, adarshCostLow = ?, adarshCostHigh = ?, percentage = ?, parathCostLow = ?, parathCostHigh = ?, costToClientLow = ?, costToClientLow = ? WHERE id = ?",
    [
      bill.taskCode,
      bill.clientName,
      bill.taskDetails,
      bill.adarshCostLow,
      bill.adarshCostHigh,
      bill.percentage,
      bill.parathCostLow,
      bill.parathCostHigh,
      bill.costToClientLow,
      bill.costToClientHigh,
      id,
    ],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // not found Project with the id
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("updated projectbilldetails: ", { id: id, ...bill });
      result(null, { id: id, ...bill });
    }
  );
};

ProjectBill.remove = (id, result) => {
  sql.query("DELETE FROM projectbilldetails WHERE id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found projectbilldetails with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted projectbilldetails with id: ", id);
    result(null, res);
  });
};

ProjectBill.removeAll = (result) => {
  sql.query("DELETE FROM projectbilldetails", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} projectbilldetails`);
    result(null, res);
  });
};

module.exports = ProjectBill;
