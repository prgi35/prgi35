const router = require("express").Router();
const employee = require("../controllers/employee.controller.js");

router.post("/login", employee.login);

// Create a new Employee
router.post("/", employee.create);

// Retrieve all Employee
router.get("/", employee.findAll);

// Retrieve a single Employee with empId
router.get("/:empId", employee.findOne);

// Update a Employee with empId
router.put("/:empId", employee.update);

// Delete a Employee with empId
router.delete("/:empId", employee.delete);

// Delete a new Employee
router.delete("/", employee.deleteAll);

module.exports = router;
