const router = require("express").Router();
const project = require("../controllers/project.controller.js");

router.post("/", project.create);

// Retrieve all Project
router.get("/", project.findAll);

// Retrieve a single Project with projectId
router.get("/:projectId", project.findOne);

// Update a Project with projectId
router.put("/:projectId", project.update);

// Delete a Project with projectId
router.delete("/:projectId", project.delete);

// Delete a new Project
router.delete("/", project.deleteAll);

module.exports = router;
