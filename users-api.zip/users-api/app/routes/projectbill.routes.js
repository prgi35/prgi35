const router = require("express").Router();
const projectBill = require("../controllers/projectbill.controller.js");

// Create a new ProjectBill
router.post("/", projectBill.create);

// Retrieve all ProjectBill
router.get("/", projectBill.findAll);

// Retrieve a single Project with projectbilldetailsId
router.get("/:projectbilldetailsId", projectBill.findOne);

// Update a Project with projectbilldetailsId
router.put("/:projectbilldetailsId", projectBill.update);

// Delete a Project with projectbilldetailsId
router.delete("/:projectbilldetailsId", projectBill.delete);

// Delete a new ProjectBill
router.delete("/", projectBill.deleteAll);

module.exports = router;
