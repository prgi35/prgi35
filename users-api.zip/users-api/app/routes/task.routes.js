const router = require("express").Router();
const task = require("../controllers/task.controller.js");

// Create a new Task
router.post("/", task.create);

// Retrieve all Task
router.get("/", task.findAll);

// Retrieve a single Task with TaskId
router.get("/:taskId", task.findOne);

// Update a Task with TaskId
router.put("/:taskId", task.update);

// Delete a Task with taskId
router.delete("/:taskId", task.delete);

// Delete a new task
router.delete("/", task.deleteAll);

module.exports = router;
