const Task = require("../models/task.model.js");
const moment = require("moment");
// Create and Save a new Project
exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }

  // console.log('body: ', req.body);



    //*******Create a Task*********
    const task = new Task({
    taskCode: req.body.taskCode,
    taskTitle: req.body.taskTitle,
    taskDescription: req.body.taskDescription,
    projectCode: req.body.projectCode,
    employeeCode: req.body.employeeCode,
    estimateTime: req.body.estimateTime,
    actualTime: req.body.actualTime,
    status: req.body.status,
    comment: req.body.comment,
    createdDate: moment().format("YYYY-MM-DD HH:mm:ss")
    
  });

  // Save Task  in the database
  Task.create(task, (err, data) => {
    if (err)
      res.status(500).send({
        success: false,
        message:
          err.message || "Some error occurred while creating the task.",
        data: null
      });
    else res.send({success: true, message: "Task created successfully.", data: data});
  });
};

exports.findAll = (req, res) => {
    Task.getAll((err, data) => {
      if (err)
        res.status(500).send({
          success: false,
          message:
            err.message || "Some error occurred while retrieving Task.",
          data: null
        });
      else res.send({success: true, message: "Task fetched successfully.", data: data});
    });
  };

  //Find a single Task with a taskId
  exports.findOne = (req, res) => {
    Task.findById(req.params.taskId, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found task with id ${req.params.taskId}.`
          });
        } else {
          res.status(500).send({
            message: "Error retrieving Task with id " + req.params.taskId
          });
        }
      } else res.send(data);
    });
};
  
  // Update a Task identified by the taskId in the request
exports.update = (req, res) => {
    // Validate Request
    if (!req.body) {
      res.status(400).send({
        message: "Content can not be empty!"
      });
    }
  
    Task.updateById(
      req.params.taskId,
      new Task(req.body),
      (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `Not found Task with id ${req.params.taskId}.`
            });
          } else {
            res.status(500).send({
              message: "Error updating Task with id " + req.params.taskId
            });
          }
        } else res.send(data);
      }
    );
 };
  

 // Delete a Task with the specified taskId in the request
exports.delete = (req, res) => {
    Task.remove(req.params.taskId, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found Task with id ${req.params.taskId}.`
          });
        } else {
          res.status(500).send({
            message: "Could not delete Task with id " + req.params.taskId
          });
        }
      } else res.send({ message: `Task was deleted successfully!` });
    });
  };
  
    // Delete all Task from the database.
  exports.deleteAll = (req, res) => {
    Task.removeAll((err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while removing all task."
        });
      else res.send({ message: `All task were deleted successfully!` });
    });
  };
