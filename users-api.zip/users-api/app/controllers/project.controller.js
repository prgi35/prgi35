const Project = require("../models/project.model.js");
const moment = require("moment");
// Create and Save a new Project
exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!",
    });
  }

  console.log("body: ", req.body);

  //*******Create a Project*********
  const project = new Project({
    projectCode: req.body.projectCode,
    projectName: req.body.projectName,
    clientName: req.body.clientName,
    address: req.body.address,
    state: req.body.state,
    country: req.body.country,
    createdDate: moment().format("YYYY-MM-DD HH:mm:ss"),
  });

  // Save Project  in the database
  Project.create(project, (err, data) => {
    if (err)
      res.status(500).send({
        success: false,
        message:
          err.message || "Some error occurred while creating the Project.",
        data: null,
      });
    else
      res.send({
        success: true,
        message: "Project created successfully.",
        data: data,
      });
  });
};

exports.findAll = (req, res) => {
  Project.getAll((err, data) => {
    if (err)
      res.status(500).send({
        success: false,
        message: err.message || "Some error occurred while retrieving Project.",
        data: null,
      });
    else
      res.send({
        success: true,
        message: "Project fetched successfully.",
        data: data,
      });
  });
};

//Find a single Project with a userId
exports.findOne = (req, res) => {
  Project.findById(req.params.projectId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Project with id ${req.params.projectId}.`,
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Project with id " + req.params.projectId,
        });
      }
    } else res.send(data);
  });
};

// Update a Project identified by the projectId in the request
exports.update = (req, res) => {
  // Validate Request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!",
    });
  }
  console.log("req.body", req.body);
  Project.updateById(
    req.params.projectId,
    new Project(req.body),
    (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found Project with id ${req.params.projectId}.`,
          });
        } else {
          res.status(500).send({
            message: "Error updating Project with id " + req.params.projectId,
          });
        }
      } else res.send(data);
    }
  );
};

// Delete a project with the specified projectId in the request
exports.delete = (req, res) => {
  Project.remove(req.params.projectId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Project with id ${req.params.projectId}.`,
        });
      } else {
        res.status(500).send({
          message: "Could not delete Project with id " + req.params.projectId,
        });
      }
    } else res.send({ message: `Project was deleted successfully!` });
  });
};

// Delete all Project from the database.
exports.deleteAll = (req, res) => {
  Project.removeAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all project.",
      });
    else res.send({ message: `All project were deleted successfully!` });
  });
};
