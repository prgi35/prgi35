const ProjectBill = require("../models/projectbill.model.js");
const moment = require("moment");
// Create and Save a new ProjectBill
exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }


  console.log("body: ", req.body);


  //*******Create a Project*********
  const projectBill = new ProjectBill({
    taskCode: req.body.projectCode,
  clientName: req.body.clientName,
  taskDetails: req.body.taskDetails,
  adarshCostLow: req.body.adarshCostLow,
  adarshCostHigh: req.body.adarshCostHigh,
  percentage: req.body.percentage,
  parathCostLow: req.body.parathCostLow,
  parathCostHigh: req.body.parathCostHigh,
  costToClientLow: req.body.costToClientLow,
  costToClientHigh: req.body.costToClientHigh,
    createdDate: moment().format("YYYY-MM-DD HH:mm:ss")

  });

  // Save Project  in the database
  ProjectBill.create(projectBill, (err, data) => {
    if (err)
      res.status(500).send({
        success: false,
        message:
          err.message || "Some error occurred while creating the ProjectBill.",
        data: null
      });
    else res.send({ success: true, message: "ProjectBill created successfully.", data: data });
  });
};

exports.findAll = (req, res) => {
  ProjectBill.getAll((err, data) => {
    if (err)
      res.status(500).send({
        success: false,
        message:
          err.message || "Some error occurred while retrieving ProjectBill.",
        data: null
      });
    else res.send({ success: true, message: "ProjectBill fetched successfully.", data: data });
  });
};

//Find a single ProjectBill with a projectbilldetailsId
exports.findOne = (req, res) => {
  ProjectBill.findById(req.params.projectbilldetailsId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found ProjectBill with id ${req.params.projectbilldetailsId}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Project with id " + req.params.projectbilldetailsId
        });
      }
    } else res.send(data);
  });
};

// Update a ProjectBill identified by the projectbilldetailsId in the request
exports.update = (req, res) => {
  // Validate Request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  console.log('req.body', req.body);
  ProjectBill.updateById(
    req.params.projectbilldetailsId,
    new Project(req.body),
    (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found ProjectBill with id ${req.params.projectbilldetailsId}.`
          });
        } else {
          res.status(500).send({
            message: "Error updating ProjectBill with id " + req.params.projectbilldetailsId
          });
        }
      } else res.send(data);
    }
  );
};


// Delete a projectBill with the specified projectId in the request
exports.delete = (req, res) => {
  ProjectBill.remove(req.params.projectbilldetailsId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found ProjectBill with id ${req.params.projectbilldetailsId}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete ProjectBill with id " + req.params.projectbilldetailsId
        });
      }
    } else res.send({ message: `ProjectBill was deleted successfully!` });
  });
};

// Delete all ProjectBill from the database.
exports.deleteAll = (req, res) => {
  ProjectBill.removeAll((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all projectBill."
      });
    else res.send({ message: `All projectBill were deleted successfully!` });
  });
};