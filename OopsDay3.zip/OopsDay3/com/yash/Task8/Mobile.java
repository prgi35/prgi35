package com.yash.Task8;

public class Mobile extends Electronic {


	public Mobile(int id2, String semicondoctorType2, String dateofManufacturing2) {
		super(id2, semicondoctorType2, dateofManufacturing2);
		// TODO Auto-generated constructor stub
	}

	public void mobiledetails() 
	{
		Electronic e= new Electronic(0,null, null);
	
	
		System.out.println("Mobile Details..."+e.toString());
		
		
	
	}
	
}
