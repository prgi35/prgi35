package com.yash.Task8;

public class LCD extends Electronic {
	
	public LCD(int id2, String semicondoctorType2, String dateofManufacturing2) {
		super(id2, semicondoctorType2, dateofManufacturing2);
		// TODO Auto-generated constructor stub
	}

	public void laptopdetails() 
	{
		Electronic e=new Electronic(1002, "12/03/2022","02/05/2021");
		
		
		
		System.out.println("LCD Details..."+e.toString());
		
	}

}
