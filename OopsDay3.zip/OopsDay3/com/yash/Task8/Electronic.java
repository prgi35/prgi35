package com.yash.Task8;

import java.util.Date;

public class Electronic {
	private int id;
	private String semicondoctorType;
	protected String dateofManufacturing;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSemicondoctorType() {
		return semicondoctorType;
	}
	public void setSemicondoctorType(String semicondoctorType) {
		this.semicondoctorType = semicondoctorType;
	}
	public String getDateofManufacturing() {
		return dateofManufacturing;
	}
	public void setDateofManufacturing(String dateofManufacturing) {
		this.dateofManufacturing = dateofManufacturing;
	}

	public Electronic(int id2, String semicondoctorType2, String dateofManufacturing2) {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Electronic [id=" + id + ", semicondoctorType=" + semicondoctorType + ", dateofManufacturing="
				+ dateofManufacturing + "]";
	}
	
	
}
	
