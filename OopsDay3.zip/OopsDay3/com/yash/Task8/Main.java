package com.yash.Task8;


public class Main {

	public static void main(String[] args) 
	{
		
		Laptop l=new Laptop(10003,"07/08/2022","23/09/2024");
		l.laptopdetails();
		
		Mobile m=new Mobile(10003,"07/08/2022","23/09/2024");
		 m.mobiledetails();
		
		//Electronics instanceOfElectronics =details();
				

	}

}
