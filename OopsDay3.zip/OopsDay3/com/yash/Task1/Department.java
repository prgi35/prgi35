package OopsDay3.Task1;

public class Department {
	private String member;
	private int deptid;
	private String dname;
	public String getMember() {
		return member;
	}
	public void setMember(String member) {
		this.member = member;
	}
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public Department(String member, String dname) {
		super();
		this.member = member;
		this.deptid = deptid;
		this.dname = dname;
	}
	
	

}
