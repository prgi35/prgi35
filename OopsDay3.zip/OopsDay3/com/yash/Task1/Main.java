package OopsDay3.Task1;

public class Main {

	public static void main(String[] args) {
		Department [] dept = new Department[2];
		
		dept[0] = new Department("Dept101","Executive Department");
		dept[1]=new Department("Dept102","Hr.Department");
		
		Employee emp = new Employee (101,"Pragati Paliwal","Burhanpur","03/05/1997",15000,
				"02/08/2021","Indore",dept[1],957528512,"pragatipaliwal@yash.com");
		
		Customer cust = new Customer(111, "Aman", "Dhar", "14/08/1997","12/03/2021", "Indore", 11450, "Ackerman@gmail.com");

		System.out.println("Employee Details -");
		 emp.printEmployeeDetails();
		 
		 System.out.println("Customer Details -");
		 cust.printCustomerDetails();
		
				
		 

	}

}
