package com.yash.Task7;

public interface CompareString {
	public void compareString();

}
