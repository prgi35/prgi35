package com.yash.Task6;


public class A {
	
	
	public void getNumbers(int number){
	
		System.out.println("For finding 3 ,4 and numbers");
	}

	
}