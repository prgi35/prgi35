package com.yash.Task4;

class OverloadMain
{
	public static void main(String[] args)
	{
			System.out.println("Yash");
			OverloadMain o=new OverloadMain();
			o.main(10);
	}
	public static void main(int a)
	{
		System.out.println("Technologies");
	}
}