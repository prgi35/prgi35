package com.yash.Task4;

import java.util.Scanner;


    	class A 
    	{        
    	          int data= 5;
    	          A(){
    	              data=10;
    	          }
    	          
    	         }  
    	         public class Test
    	         {
    	                 public static void main(String[] args) {
    	                     A obj = new A();
    	                     System.out.println(obj.data);
    	         }
    	}
