package com.yash.Task4;
class MethodLoad
{
	void show1(int a)
	{
		System.out.println("Yash");
	}
	void show(int a)
	{
		System.out.println("Technologies");
	}
	public static void main(String[] args)
	{
			MethodLoad ml=new MethodLoad();
			ml.show(10);
			//m1.show("jaynam");
	}
}
		

