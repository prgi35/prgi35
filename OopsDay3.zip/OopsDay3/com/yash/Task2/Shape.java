package com.yash.Task2;

public interface Shape {

	public double area();


}
