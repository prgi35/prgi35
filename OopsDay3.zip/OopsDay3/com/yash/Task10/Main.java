package com.yash.Task10;


/// WAP to demonstrate the use of clone method. Clone one object of 
//Product class :- pid, pname, price and unitOfMeasurement. When you 
//clone object of class Product change the product name and price. With 
//the help of instanceOf check that the newly created object is belong to 
//Product class or not.


public class Main {
	public static void main (String []args)
			throws CloneNotSupportedException
	{
		
		Product p = new Product (10001,"Kit",20,"Kat");
		
		Product p1=(Product)p.clone()
		p.setPname("KitKat");
		p.setPrice(40);
		
		System.out.println(p1);
		if(p1 instanceof Product) {
			System.out.println("Objects are same");
		}
	}

}

