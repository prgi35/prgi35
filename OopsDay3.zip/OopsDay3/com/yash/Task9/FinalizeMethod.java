package com.yash.Task9;

public class FinalizeMethod {
	
	public static void main(String[]args) {
		
		Person p1 = new Person(101);
		Person p2 = new Person(102);
		Person p3= new Person(103);
		
		p2=null;
		p3=null;
		System.gc();
		
		for (int i=1;i<5;i++) {
			String p= "p"+i;
			System.out.println(p+":"+p.hashCode());
			
		}
		System.out.println("p1="+p1);
		System.out.println("p3="+p3);
	}

}
