package com.yash.Task9;
///9) With the help of finalize method print the how many objects are currently 
//a class is having and which object is going to be freed from the memory 
//with its hashcode.
public class Person {
	
	int id;

	public Person(int id) {
		super();
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + ", getId()=" + getId() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	
	

}
