package com.yash.Task3;

public class Customer {
	int CustId;
	int accountno;
	String custname;
	String cust_address;
	String cust_dob;
	String cust_account_opening_date;
	String Branch_obj;
	@Override
	public String toString() {
		return "Customer [CustId=" + CustId + ", accountno=" + accountno + ", custname=" + custname + ", cust_address="
				+ cust_address + ", cust_dob=" + cust_dob + ", cust_account_opening_date=" + cust_account_opening_date
				+ ", Branch_obj=" + Branch_obj + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	public Customer(int custId, int string, String custname, String cust_address, String cust_dob,
			String i, String b1) {
		super();
		CustId = custId;
		this.accountno = string;
		this.custname = custname;
		this.cust_address = cust_address;
		this.cust_dob = cust_dob;
		this.cust_account_opening_date = i;
		Branch_obj = b1;
	}
	

}
