package com.yash.Task3;

public class Main {
	public static void main(String[] args) {
		Branch b1 = new Branch(111,"BOI","Burhanpur");
		System.out.println("Details of branch b1==>");
		System.out.println(b1);
		
		
		Branch b2 = new Branch(112,"Syenticate","Shahpur");
		System.out.println("Details of branch b2==>");
		System.out.println(b2);
		
		
		Branch b3 = new Branch(113,"SBI","Khandwa");
		System.out.println("Details of branch b3==>");
		System.out.println(b3);
		
		
		///For Customer Details
		
		System.out.println("******Customer Details*****");
		
		Customer c1= new Customer(211,10000,"Pragati","Burhanpur","10/08/2021","02/07/2021","b1");
		System.out.println("***Details of Customer c1***");
		System.out.println(c1);
		
		Customer c2= new Customer(212,15000,"Vishu","Nepanager","27/06/2021","03/09/1900","b2");
		System.out.println("***Details of Customer c2***");
		System.out.println(c2);
		
		Customer c3= new Customer(213,20000,"Kajal","Shahpur","21/08/2022","08/03/2021","b3");
		System.out.println("***Details of Customer c1***");
		System.out.println(c1);
		
		System.out.println("*****All the details of Customer_Account_Statement*****");
		
		Customer_Account_Statment ca1 = new Customer_Account_Statment(501, 1200, "500", "22/07/20","c1");
		System.out.println("***Details of Customer_Account_Statement ca1***");
		System.out.println(ca1);
		
		Customer_Account_Statment ca2 = new Customer_Account_Statment(502, 2000, "7000", "22/07/20","c2");
		System.out.println("***details of Customer_Account_Statement ca2***");
		System.out.println(ca2);
		
		Customer_Account_Statment ca3 = new Customer_Account_Statment(503,3000, "800", "21/07/21","c3");
		System.out.println("***details of Customer_Account_Statement ca3***");
		System.out.println(ca3);
		
	}
}	
