package com.yash.Task3;

public class Customer_Account_Statment {
	int CAID;
	int amount;
	String deposit_withdrawl;
	String deposite_date;
	String CustId;
	public Customer_Account_Statment(int cAID, int amount, String deposit_withdrawl, String deposite_date,
			String custId) {
		super();
		CAID = cAID;
		this.amount = amount;
		this.deposit_withdrawl = deposit_withdrawl;
		this.deposite_date = deposite_date;
		CustId = custId;
	}
	@Override
	public String toString() {
		return "Customer_Account_Statment [CAID=" + CAID + ", amount=" + amount + ", deposit_withdrawl="
				+ deposit_withdrawl + ", deposite_date=" + deposite_date + ", CustId=" + CustId + "]";
	}
	
	
	

}
