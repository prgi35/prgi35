package com.yash.Task5;

public abstract class B extends A {
	
	   public void sub(int a, int b)
	    {
		   int c=a-b;
			System.out.println("Sub :- "+c);
		   
		}

		


	}
