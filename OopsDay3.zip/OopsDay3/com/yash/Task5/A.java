package com.yash.Task5;


public abstract class A extends CalcAbs {

	public void sum(int a, int b) {
		
		int c=a+b;
		System.out.println("Sum :- "+c);
	
		
	}

	
	

}
