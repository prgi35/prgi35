package com.yash.Task11;


//
//11) WAP to print the object of Employee class with the help of 
//toString method. Employee class fields :- empid, empname, empsalary, 
//empaddress, emp_dob, emp_doj. use Date class to store the date of 
//birth(dob) and date of joining(doj).
public class Main {
	public static void main (String[] args) {
		Employee e = new Employee(101,"Pragati",1500000.00,"Burhanpur","03/05/1997","02/08/2021");
		System.out.println("Employeee Details---"+e.toString());
	}

}
