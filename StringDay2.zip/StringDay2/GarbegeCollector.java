//7) WAP to demonstrate how garbage collector work when any memory is not referenced by string 
//object.
package StringDay2;



public class GarbegeCollector {
	
	String str;

   public GarbegeCollector(String str) {
	            this.str = str;
	        }

	   @Override
	    protected void finalize() throws Throwable {
	        super.finalize();
	        System.out.println(this.str + " collected");
	    }

	   public static void main(String[] args) {
	        GarbegeCollector gcc = new GarbegeCollector("Pragati");
	        System.out.println("String=" + gcc.str.toString());
	        gcc = null;
	        System.gc();



	   }

}
