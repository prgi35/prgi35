//6) WAP to demonstrate how memory is allocated to string objects in memory heap and string 
//constant pool.

package StringDay2;

public class MemoryAllocationSCP {

	public static void main(String[] args)
	{
		
		String s1 = "xyz";
		String s2 = "xyz";

		String s3 = new String("abc");
		String s4 = new String("abc");
		
         System.out.println("s1 -"+s1.hashCode());
         System.out.println("s2 -"+s2.hashCode());
         System.out.println("s3 -"+s3.hashCode());
         System.out.println("s4 -"+s4.hashCode());
         
		//scp  
		if (s1 == s2)
		System.out.println("Yes");
		else
		System.out.println("No");

		//Heap
		if (s3 == s4)
		System.out.println("Yes");
		else
		System.out.println("No");
		

	}
}
