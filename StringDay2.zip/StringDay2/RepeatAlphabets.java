//4) WAP to print the number of alphabets repeated in the given string.
package StringDay2;

public class RepeatAlphabets {

	public static void main(String[] args) {
        String s = "PragatiPaliwal";
        
        char [] a= s.toCharArray();
        
        for(int i=0; i<a.length; i++)
        {
            int Count=1;
            for(int j=i+1; j<a.length; j++)
            {
                if(a[i]==a[j])
                {
                    Count++;
                   
                }
                
            }
            if(Count > 1)
            {
                System.out.println(a[i]+"  no:- "+Count);
            }
        }
    }

}
